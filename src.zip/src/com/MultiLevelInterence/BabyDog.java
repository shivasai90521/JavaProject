package com.MultiLevelInterence;

public class BabyDog extends Dog{
    public void weep(){
        System.out.println("weeping...");
    }
}