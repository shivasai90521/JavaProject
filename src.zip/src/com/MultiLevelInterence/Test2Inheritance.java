package com.MultiLevelInterence;

public class Test2Inheritance {
    public static void main(String[] args) {
        BabyDog bab = new BabyDog();
        bab.bark();
        bab.eat();
        bab.weep();
    }
}