package com.RunTimePolymorphismExample;

public class OverrideTest {
    public static void main(String[] args) {
        Asus as=new Asus();
        as.test();
    }
}
