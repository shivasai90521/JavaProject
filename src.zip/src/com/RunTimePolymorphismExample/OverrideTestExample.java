package com.RunTimePolymorphismExample;

public class OverrideTestExample {
    public static void main(String[] args) {
        Dog d = new Dog(2,7);
        d.eat();
    }
}