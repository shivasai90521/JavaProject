package com.RunTimePolymorphismExample;

public class Laptop {
    public void test(){
        System.out.println("This is new laptop");
    }
}
