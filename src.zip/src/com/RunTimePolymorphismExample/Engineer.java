package com.RunTimePolymorphismExample;

public class Engineer {
    public void work(){
        System.out.println("Engineer Works");
    }
}
