package com.PracticeExamples;

public class GreatestNumber {
    public static void main(String[] args) {
        int a=18,b=10,c;
        c=(a>b)?a:b;
        System.out.println(c);
    }
}
