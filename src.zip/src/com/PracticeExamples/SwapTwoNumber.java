package com.PracticeExamples;

public class SwapTwoNumber {
    public static void main(String[] args) {
//        int a=10,b=20,temp;
//        temp=b;
//        b=a;
//        a=temp;
//        System.out.println("a="+a);
//        System.out.println("b ="+b);
     int a=20,b=40;
     a=a+b;
     b=a-b;
     a=a-b;
        System.out.println("a="+a);
        System.out.println("b="+b);


    }
}