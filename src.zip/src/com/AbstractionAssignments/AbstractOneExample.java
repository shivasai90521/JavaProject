package com.AbstractionAssignments;

public abstract class AbstractOneExample {
    public void m1(){
       System.out.println("This is Concrete method");
    }

}
