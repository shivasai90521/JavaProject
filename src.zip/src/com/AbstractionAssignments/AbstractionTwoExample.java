package com.AbstractionAssignments;

public abstract class AbstractionTwoExample {
    public abstract void m2();
    public abstract void m3();
    public abstract void m4();
    public abstract void m5();
}

