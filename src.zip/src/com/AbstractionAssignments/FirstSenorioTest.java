package com.AbstractionAssignments;

public class FirstSenorioTest extends AbstractOneExample{
    public static void main(String[] args) {
        FirstSenorioTest f=new FirstSenorioTest();
        f.m1();
    }
}
