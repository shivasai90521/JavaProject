package com.AbstractionAssignments;

public abstract class AbstractionThreeExample extends AbstractionTwoExample{
    @Override
    public void m2() {
        System.out.println("This is m2");
    }

    @Override
    public void m3() {
        System.out.println("This is m3");

    }
}
