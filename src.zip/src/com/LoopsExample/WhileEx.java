package com.LoopsExample;

public class WhileEx {
    public static void main(String[] args) {
        int i=11;
        while (i<=10){
            i++;
            System.out.println("The 'i' value is: "+i);
        }
        System.out.println("It is not looping value is: "+i);
    }
}
