package com.ArrayExample;

public class ArrayExample1 {
    public static void main(String[] args) {
        int [] exampleArray={1,2,3,4,5};
        for (int i=0;i<exampleArray.length;i++){
            System.out.println(exampleArray[i]);
        }
        int example = exampleArray.length;
        System.out.println("This Java array size is: "+example);
    }
}
