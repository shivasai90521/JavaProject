package com.ArrayExample;

public class StringArrayExample{
    public static void main(String[] args) {
        String str[] ={"hello","Array","program"};
        for (int i=0; i<str.length;i++) {
            System.out.println(str[i]);
        }
            int s= str.length;
            System.out.println("This is size of Array is: "+s);

        }
    }
