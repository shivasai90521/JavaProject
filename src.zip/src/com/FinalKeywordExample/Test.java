package com.FinalKeywordExample;

public class Test extends FinalVariableExample{
    public final int a=10;

}
