package com.IntroductionExample;

public class RunnableEx implements Runnable{

    @Override
    public void run() {
       String s="hello";

    }
}
