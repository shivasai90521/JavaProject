package com.IntroductionExample;

import java.util.Scanner;

public class SwapExample {
    public static void main(String[] args) {
        int x,y,t;
        System.out.println("before swaping");

       // t=x;
        //x=y;
      //  y=t;


    }

}
