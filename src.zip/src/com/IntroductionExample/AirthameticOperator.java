package com.IntroductionExample;

public class AirthameticOperator {
    public static void main(String[] args) {
        int a=10,b=20;
        System.out.println("addition of two numbers: "+(a+b));
        System.out.println("subtraction of two numbers: "+(a-b));
        System.out.println("multiplication of two number: "+(a*b));
        System.out.println("division of two number: "+(a/b));
        System.out.println("modulus of two number: "+(a%b));
    }

}
