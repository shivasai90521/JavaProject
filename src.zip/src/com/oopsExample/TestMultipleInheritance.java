package com.oopsExample;

public class TestMultipleInheritance implements InterfaceExample1,InterfaceExample2{
    @Override
    public void m1() {

    }

    @Override
    public void m2() {

    }

    @Override
    public void display() {

    }
    public void m3(){

    }
}
