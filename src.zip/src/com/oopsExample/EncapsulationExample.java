package com.oopsExample;

public class EncapsulationExample {
    private int id;
    private String name;
    private String email;
    private String place;

    public void setId(int id){
        this.id=id;
    }
    public int getId(){
        return id;
    }
    public void setName(String name){
        this.name=name;
    }
    public String getName(){
        return name;
    }
    public void setEmail(String email){
        this.email=email;
    }
    public String getEmail(){
        return email;
    }
    public void setPlace(String place){
        this.place=place;
    }
    public String getPlace(){
        return place;
    }

    public static void main(String[] args) {
        EncapsulationExample ex=new EncapsulationExample();
        ex.setId(1001);
        ex.setName("Shiva");
        ex.setEmail("Shivasai@gmail.com");
        ex.setPlace("Bangalore");
       String e=ex.getEmail();
       int f=ex.getId();
       String g=ex.getName();
       String h=ex.getPlace();
        System.out.println(e+":"+f+":"+g+":"+ h);
    }
}
