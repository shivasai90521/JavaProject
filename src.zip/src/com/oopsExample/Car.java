package com.oopsExample;

public class Car {
    public void colour(){
        System.out.println("colour of car");
    }
    public void wheels(){
        System.out.println("Wheels of car");
    }
}
class D extends Car{

}