package com.oopsExample;

public interface InterfaceExample2 {
    void m1();
    void m3();
}
