package com.BasicJavaPrograms;

public class Example1 {
    public Example1(){
        int i=20;
        int j=30;
        int c=i+j;
        System.out.println(c);
    }

    public static void main(String[] args) {
        Example1 ex=new Example1();
    }
}
