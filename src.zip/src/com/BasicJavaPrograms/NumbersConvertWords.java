package com.BasicJavaPrograms;

public class NumbersConvertWords {
    public static void main(String[] args) {
        int a=1234;
        int b=-1233;
        String str1=Integer.toString(a);
        String str2=Integer.toString(b);
        System.out.println("str1="+str1);
        System.out.println("str2="+str2);
    }
}
