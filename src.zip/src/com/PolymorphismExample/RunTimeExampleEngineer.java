package com.PolymorphismExample;

public class RunTimeExampleEngineer {
    public void work(){
        System.out.println("Engineer Works");
    }
}
