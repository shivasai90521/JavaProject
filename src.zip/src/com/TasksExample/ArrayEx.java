package com.TasksExample;

public class ArrayEx {
    public static void main(String[] args) {
        int arr[] = new int[]{1, 2, 3, 4, 5};
        int temp;
        for (int i=arr.length-1;i>=0;i--){
            System.out.print(arr[i]);
//            int ex=arr.length;
            System.out.println("The length of array:");
        }
    }
}